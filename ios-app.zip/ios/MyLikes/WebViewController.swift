import UIKit
import WebKit

/// The whole app: your My Likes site in a full-screen web view.
///
/// - Where the site is: the address baked in when the app was built (the SITE_URL build setting, from the GitHub workflow's
///   "site_url" box), or else the one typed on first launch. Shake the phone to reload or to change the address.
/// - Links to other sites (SoundCloud pages, YouTube searches, artist links) open in Safari; the player stays put.
/// - Saving a file from the site (exported likes, cover art, a downloaded track) opens the Share sheet, where "Save to Files" keeps it.
final class WebViewController: UIViewController, WKNavigationDelegate, WKUIDelegate, WKDownloadDelegate {
    private var webView: WKWebView!
    private var asked = false
    private var downloads: [ObjectIdentifier: URL] = [:]

    private static let savedKey = "siteURL"
    private static let background = UIColor(red: 0x11 / 255.0, green: 0x1a / 255.0, blue: 0x33 / 255.0, alpha: 1)

    /// The site to show: the one typed in the app wins over the one built in.
    private var siteURL: URL? {
        if let s = UserDefaults.standard.string(forKey: Self.savedKey), let u = Self.clean(s) { return u }
        if let s = Bundle.main.object(forInfoDictionaryKey: "SiteURL") as? String, let u = Self.clean(s) { return u }
        return nil
    }

    /// "my-likes.vercel.app" -> https://my-likes.vercel.app ; nil for anything that isn't a web address.
    static func clean(_ raw: String) -> URL? {
        var s = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        if s.isEmpty || s.hasPrefix("$(") { return nil }
        let lower = s.lowercased()
        if !lower.hasPrefix("http://") && !lower.hasPrefix("https://") { s = "https://" + s }
        guard let u = URL(string: s), let host = u.host, !host.isEmpty, !s.contains(" ") else { return nil }
        return u
    }

    override func loadView() {
        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []
        config.websiteDataStore = .default() // your settings, accounts and loaded skins are kept between launches

        let web = WKWebView(frame: .zero, configuration: config)
        web.navigationDelegate = self
        web.uiDelegate = self
        web.allowsLinkPreview = false // holding a song's title opens the site's own card instead of the iOS link preview
        web.allowsBackForwardNavigationGestures = false
        web.scrollView.contentInsetAdjustmentBehavior = .never // the site lays itself out around the notch and home bar
        web.scrollView.bounces = false
        web.isOpaque = false
        web.backgroundColor = Self.background
        web.scrollView.backgroundColor = Self.background
        if #available(iOS 16.4, *) { web.isInspectable = true } // Safari's Web Inspector works on it, for debugging
        webView = web
        view = web
    }

    override var preferredStatusBarStyle: UIStatusBarStyle { .lightContent }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        becomeFirstResponder()
        if webView.url == nil && !asked { start() }
    }

    private func start() {
        if let u = siteURL { webView.load(URLRequest(url: u)) } else { askForAddress(first: true) }
    }

    private func askForAddress(first: Bool) {
        asked = true
        guard presentedViewController == nil else { return }
        let alert = UIAlertController(title: first ? "Where is your My Likes site?" : "Change the site address",
                                      message: "Type the web address of your deployed player, for example my-likes.vercel.app.",
                                      preferredStyle: .alert)
        alert.addTextField { field in
            field.placeholder = "my-likes.vercel.app"
            field.keyboardType = .URL
            field.autocapitalizationType = .none
            field.autocorrectionType = .no
            field.clearButtonMode = .whileEditing
            field.text = self.siteURL?.absoluteString
        }
        alert.addAction(UIAlertAction(title: "Open", style: .default) { [weak self, weak alert] _ in
            guard let self = self else { return }
            let text = alert?.textFields?.first?.text ?? ""
            if let u = Self.clean(text) {
                UserDefaults.standard.set(u.absoluteString, forKey: Self.savedKey)
                self.webView.load(URLRequest(url: u))
            } else {
                DispatchQueue.main.async { self.askForAddress(first: first) }
            }
        })
        if !first { alert.addAction(UIAlertAction(title: "Cancel", style: .cancel)) }
        present(alert, animated: true)
    }

    // MARK: shake the phone: reload, or change the site address

    override var canBecomeFirstResponder: Bool { true }

    override func motionEnded(_ motion: UIEvent.EventSubtype, with event: UIEvent?) {
        guard motion == .motionShake, presentedViewController == nil else { return }
        let menu = UIAlertController(title: "My Likes", message: siteURL?.host, preferredStyle: .actionSheet)
        menu.addAction(UIAlertAction(title: "Reload", style: .default) { [weak self] _ in
            guard let self = self else { return }
            if self.webView.url == nil { self.start() } else { self.webView.reload() }
        })
        menu.addAction(UIAlertAction(title: "Change site address", style: .default) { [weak self] _ in
            self?.askForAddress(first: false)
        })
        menu.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        if let pop = menu.popoverPresentationController { // iPad
            pop.sourceView = view
            pop.sourceRect = CGRect(x: view.bounds.midX, y: view.bounds.midY, width: 1, height: 1)
            pop.permittedArrowDirections = []
        }
        present(menu, animated: true)
    }

    // MARK: links

    private func isOtherSite(_ url: URL) -> Bool {
        guard let mine = siteURL?.host?.lowercased(), let host = url.host?.lowercased() else { return false }
        return host != mine
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url else { decisionHandler(.cancel); return }
        let scheme = url.scheme?.lowercased() ?? ""
        if navigationAction.shouldPerformDownload { decisionHandler(.download); return }
        if scheme == "about" || scheme == "blob" || scheme == "data" { decisionHandler(.allow); return }
        if scheme != "http" && scheme != "https" { // mail, phone, App Store and other apps' links
            UIApplication.shared.open(url)
            decisionHandler(.cancel)
            return
        }
        let mainFrame = navigationAction.targetFrame?.isMainFrame ?? true
        if mainFrame && navigationAction.navigationType == .linkActivated && isOtherSite(url) {
            UIApplication.shared.open(url)
            decisionHandler(.cancel)
            return
        }
        decisionHandler(.allow) // the site itself, and frames inside it (the SoundCloud player, skin frames)
    }

    /// Links that ask for a new tab (target="_blank", window.open) open in Safari.
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if let url = navigationAction.request.url {
            let scheme = url.scheme?.lowercased() ?? ""
            if scheme == "http" || scheme == "https" {
                if isOtherSite(url) { UIApplication.shared.open(url) } else { webView.load(URLRequest(url: url)) }
            }
        }
        return nil
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationResponse: WKNavigationResponse,
                 decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
        decisionHandler(navigationResponse.canShowMIMEType ? .allow : .download)
    }

    // MARK: saving files

    func webView(_ webView: WKWebView, navigationAction: WKNavigationAction, didBecome download: WKDownload) {
        download.delegate = self
    }

    func webView(_ webView: WKWebView, navigationResponse: WKNavigationResponse, didBecome download: WKDownload) {
        download.delegate = self
    }

    func download(_ download: WKDownload, decideDestinationUsing response: URLResponse, suggestedFilename: String,
                  completionHandler: @escaping (URL?) -> Void) {
        let dir = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        let name = suggestedFilename.isEmpty ? "download" : suggestedFilename
        let file = dir.appendingPathComponent(name)
        downloads[ObjectIdentifier(download)] = file
        completionHandler(file)
    }

    func downloadDidFinish(_ download: WKDownload) {
        guard let file = downloads.removeValue(forKey: ObjectIdentifier(download)) else { return }
        let share = UIActivityViewController(activityItems: [file], applicationActivities: nil)
        if let pop = share.popoverPresentationController {
            pop.sourceView = view
            pop.sourceRect = CGRect(x: view.bounds.midX, y: view.bounds.maxY - 80, width: 1, height: 1)
        }
        (presentedViewController ?? self).present(share, animated: true)
    }

    func download(_ download: WKDownload, didFailWithError error: Error, resumeData: Data?) {
        downloads.removeValue(forKey: ObjectIdentifier(download))
        say("The file couldn't be saved", error.localizedDescription)
    }

    // MARK: problems

    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        showProblem(error)
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        showProblem(error)
    }

    /// The page's process was stopped by iOS (usually to free memory while in the background): load it again.
    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        if webView.url == nil { start() } else { webView.reload() }
    }

    private func showProblem(_ error: Error) {
        let e = error as NSError
        if e.domain == NSURLErrorDomain && e.code == NSURLErrorCancelled { return }
        if e.domain == "WebKitErrorDomain" && (e.code == 102 || e.code == 204) { return } // a load this app stopped on purpose
        guard presentedViewController == nil else { return }
        let alert = UIAlertController(title: "Couldn't open the player", message: e.localizedDescription, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Try again", style: .default) { [weak self] _ in self?.start() })
        alert.addAction(UIAlertAction(title: "Change site address", style: .default) { [weak self] _ in
            DispatchQueue.main.async { self?.askForAddress(first: false) }
        })
        present(alert, animated: true)
    }

    private func say(_ title: String, _ message: String?) {
        guard presentedViewController == nil else { return }
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }

    // MARK: the site's own alert / confirm boxes

    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler() })
        if presentedViewController == nil { present(alert, animated: true) } else { completionHandler() }
    }

    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
        let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel) { _ in completionHandler(false) })
        alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler(true) })
        if presentedViewController == nil { present(alert, animated: true) } else { completionHandler(false) }
    }
}
